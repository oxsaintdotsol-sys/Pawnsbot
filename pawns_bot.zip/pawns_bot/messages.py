"""
PAWNS Bot — Message templates
"""
from utils import format_currency, format_date, format_datetime, format_countdown


def investment_activated_msg(inv):
    return (
        f"*PAWNS INVESTMENT ACTIVATED ♟️*\n\n"
        f"Investment Amount: {format_currency(inv['amount'])}\n"
        f"Plan: {inv['plan_label']}\n"
        f"Start Date: {format_date(inv['start_ts'])}\n"
        f"Maturity Date: {format_date(inv['maturity_ts'])}\n\n"
        f"Investment Status: *ACTIVE* 🟢\n\n"
        f"Your investment countdown has started."
    )


def investment_dashboard_msg(inv, remaining_secs):
    countdown = format_countdown(remaining_secs)
    status_icon = "🟢" if inv['status'] == 'ACTIVE' else "🔴"
    return (
        f"*♟️ PAWNS INVESTMENT DASHBOARD*\n\n"
        f"Investment ID: `{inv['investment_id']}`\n"
        f"Investment: {format_currency(inv['amount'])}\n"
        f"Plan: {inv['plan_label']}\n\n"
        f"Start Date: {format_date(inv['start_ts'])}\n"
        f"Maturity Date: {format_date(inv['maturity_ts'])}\n\n"
        f"*Time Remaining:*\n"
        f"`{countdown}`\n\n"
        f"Status: {status_icon} {inv['status']}\n"
        f"Recorded Balance: {format_currency(inv['recorded_balance'])}\n\n"
        f"_Payout is subject to your signed investment agreement._"
    )


def withdrawal_locked_msg(remaining_secs):
    countdown = format_countdown(remaining_secs)
    return (
        f"*⏳ WITHDRAWAL LOCKED*\n\n"
        f"Your current investment term has not reached maturity.\n\n"
        f"*Time Remaining:*\n"
        f"`{countdown}`\n\n"
        f"Withdrawal requests will become available when the applicable "
        f"investment term reaches its maturity date, subject to the investment agreement."
    )


def withdrawal_available_msg(inv):
    return (
        f"*🟢 INVESTMENT MATURED*\n\n"
        f"Your investment has reached its scheduled maturity date.\n\n"
        f"Withdrawal requests are now available according to the applicable investment agreement.\n\n"
        f"Available Balance: *{format_currency(inv['recorded_balance'])}*"
    )


def withdrawal_request_msg(available):
    return (
        f"*WITHDRAWAL REQUEST*\n\n"
        f"Available amount: *{format_currency(available)}*\n\n"
        f"Please enter the amount you would like to withdraw:"
    )


def withdrawal_confirm_msg(amount, network, wallet):
    return (
        f"*CONFIRM WITHDRAWAL*\n\n"
        f"Amount: *{format_currency(amount)}*\n"
        f"Network: *{network}*\n"
        f"Wallet:\n`{wallet}`\n\n"
        f"⚠️ Please verify that the wallet address and network are correct before confirming."
    )


def withdrawal_submitted_msg(req_id, amount):
    return (
        f"*⏳ WITHDRAWAL REQUEST SUBMITTED*\n\n"
        f"Request ID: `{req_id}`\n"
        f"Amount: *{format_currency(amount)}*\n"
        f"Status: *PENDING REVIEW*\n\n"
        f"The PAWNS administration team will process your request according to the applicable withdrawal terms."
    )


def admin_new_withdrawal_msg(investor, wd, inv):
    return (
        f"🔔 *NEW WITHDRAWAL REQUEST*\n\n"
        f"Investor: @{investor['username'] or 'N/A'}\n"
        f"User ID: `{investor['telegram_id']}`\n"
        f"Investment ID: `{inv['investment_id']}`\n\n"
        f"Amount: *{format_currency(wd['amount'])}*\n"
        f"Network: *{wd['network']}*\n"
        f"Wallet:\n`{wd['wallet_address']}`\n\n"
        f"Request ID: `{wd['request_id']}`\n"
        f"Submitted: {format_datetime(wd['created_at'])}"
    )


def no_investment_msg():
    return (
        "♟️ *PAWNS Investment*\n\n"
        "You don't have an active investment yet.\n\n"
        "Please contact support or send your payment to get started."
    )


def transaction_history_msg(withdrawals):
    if not withdrawals:
        return "📜 *TRANSACTION HISTORY*\n\nNo transactions found."
    lines = ["📜 *TRANSACTION HISTORY*\n"]
    for w in withdrawals:
        lines.append(
            f"• `{w['request_id']}`\n"
            f"  Amount: {format_currency(w['amount'])}\n"
            f"  Network: {w['network']}\n"
            f"  Status: *{w['status']}*\n"
            f"  Date: {format_datetime(w['created_at'])}\n"
        )
    return "\n".join(lines)


# ── Notification messages ─────────────────────────────────────

def notif_activated():
    return "♟️ *PAWNS:* Your investment has been activated. The countdown has started."


def notif_7days():
    return "♟️ *PAWNS:* Your investment is scheduled to mature in *7 days*."


def notif_24hours():
    return "♟️ *PAWNS:* Your investment is scheduled to mature in approximately *24 hours*."


def notif_matured():
    return (
        "🟢 *PAWNS:* Your investment has reached its scheduled maturity date. "
        "Withdrawal requests are now available according to your investment agreement."
    )
