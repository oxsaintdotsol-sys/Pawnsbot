"""
PAWNS Bot — Shared utility functions
"""
from datetime import datetime, timezone


def utcnow():
    return datetime.now(timezone.utc)


def parse_ts(ts_str):
    """Parse an ISO timestamp string into a timezone-aware datetime."""
    if ts_str is None:
        return None
    try:
        dt = datetime.fromisoformat(ts_str)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        return None


def format_countdown(remaining_seconds):
    """Return 'DD Days : HH Hours : MM Minutes' string from total seconds."""
    if remaining_seconds <= 0:
        return "00 Days : 00 Hours : 00 Minutes"
    days = int(remaining_seconds // 86400)
    hours = int((remaining_seconds % 86400) // 3600)
    minutes = int((remaining_seconds % 3600) // 60)
    return f"{days} Days : {hours:02d} Hours : {minutes:02d} Minutes"


def format_currency(amount):
    return f"${amount:,.2f}"


def format_date(ts_str):
    dt = parse_ts(ts_str)
    if dt is None:
        return "N/A"
    return dt.strftime("%d/%m/%Y")


def format_datetime(ts_str):
    dt = parse_ts(ts_str)
    if dt is None:
        return "N/A"
    return dt.strftime("%d %b %Y, %H:%M UTC")


def investment_remaining_seconds(maturity_ts_str):
    maturity = parse_ts(maturity_ts_str)
    if maturity is None:
        return 0
    remaining = (maturity - utcnow()).total_seconds()
    return max(0, remaining)


def is_matured(maturity_ts_str):
    return investment_remaining_seconds(maturity_ts_str) <= 0
